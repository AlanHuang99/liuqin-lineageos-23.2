#!/system/bin/sh
# Neutralize the SecureElement OMAPI feature declarations before system_server
# reads them, so SecureElementManagerService never starts (no SE hardware here).
MODDIR=${0%/*}
for f in android.hardware.se.omapi.ese.xml android.hardware.se.omapi.uicc.xml; do
  t="/vendor/etc/permissions/$f"
  if [ -f "$t" ]; then
    mount -o bind "$MODDIR/empty_permissions.xml" "$t"
  fi
done
